#' R version
#' 
#' Returns \code{unclass(R.version)}
#' @export
get_r_version = function() unclass(R.version)
