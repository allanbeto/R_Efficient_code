#' Platform information
#' 
#' This function just returns the outpu of \code{.Platform}
#' @export
get_platform_info = function() .Platform
